"""
Typing module of pymongohelper
"""

__all__ = ['DocumentType']

from pymongo.typings import _DocumentType as DocumentType